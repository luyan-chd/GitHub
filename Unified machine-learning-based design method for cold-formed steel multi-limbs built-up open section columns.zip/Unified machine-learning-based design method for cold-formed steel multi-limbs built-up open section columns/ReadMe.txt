#The code was written by Yan Lu （School of Civil Engineering Inner Mongolia University of Technology, Hohhot, Inner Mongolia, China）. 
#For more details on the related code, please refer to the paper titled "Unified machine-learning-based design method 
for cold-formed steel multi-limbs built-up open section columns," published in the Structures.
#For any questions regarding the code or the paper, please contact Yan Lu via email at luyanchd@163.com.