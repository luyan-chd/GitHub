import pandas as pd
from sklearn.model_selection import train_test_split

# 读取原始数据
data = pd.read_csv("Dataset_with_nomalization.csv")  # 假设原始数据文件名为Data.csv

# 划分数据集
train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)

# 保存训练集和测试集
train_data.to_csv("Data_Train.csv", index=False)  # 保存训练集
test_data.to_csv("Data_Test.csv", index=False)    # 保存测试集