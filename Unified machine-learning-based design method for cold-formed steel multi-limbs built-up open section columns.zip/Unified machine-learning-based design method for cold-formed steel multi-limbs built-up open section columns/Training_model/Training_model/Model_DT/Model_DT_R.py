import pandas as pd
from sklearn.model_selection import train_test_split, KFold, GridSearchCV
from sklearn.preprocessing import MinMaxScaler
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import r2_score, mean_absolute_error
import numpy as np
import joblib

# Read the data
df1 = pd.read_csv('Data_Train_R.csv')
df2 = pd.read_csv('Data_Test_R.csv')

# Features and target variable
X_train = df1.drop('Pt', axis=1)  # Drop the target column
y_train = df1['Pt']  # Target variable is 'Pt'

X_test = df2.drop('Pt', axis=1)  # Drop the target column
y_test = df2['Pt']  # Target variable is 'Pt'

# Print the features and target variables
print(X_train)
print(y_train)

print(X_test)
print(y_test)

# This version provides the grid search algorithm. The hybrid algorithms #
# (including binary search, genetic algorithms, particle swarm optimization, etc.) #
# will be included in future updates
param_grid = {
    'max_depth': range(1, 40)  # Range of values for max_depth parameter
}

# Initialize the decision tree regressor
dt_reg = DecisionTreeRegressor()

# Initialize 10-fold cross-validation
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# Store the best parameters and scores for each round
best_params_scores = []

# Repeat the training process for 10 rounds
for round_num in range(10):
    print(f"Round {round_num + 1}")

    # Initialize GridSearchCV for hyperparameter tuning
    grid_search = GridSearchCV(estimator=dt_reg, param_grid=param_grid, cv=kf, scoring='r2')

    # Perform grid search on the training set
    grid_search.fit(X_train, y_train)

    # Get the best parameters and model
    best_params = grid_search.best_params_
    best_score = grid_search.best_score_
    best_params_scores.append((best_params, best_score))

# Find the best parameters based on the highest average score
best_params_avg_score = max(best_params_scores, key=lambda x: x[1])[0]
print("Best parameters based on average score across 10 rounds:", best_params_avg_score)

# Train the model again using the best parameters on the entire training set
best_model = DecisionTreeRegressor(**best_params_avg_score)
best_model.fit(X_train, y_train)

# Evaluate the model's performance
y_pred = best_model.predict(X_test)

# Calculate R²
r2 = r2_score(y_test, y_pred)

# Calculate MAE (Mean Absolute Error)
mae = mean_absolute_error(y_test, y_pred)

# Calculate the mean and covariance between predictions and actual values
mean = np.mean(y_pred / y_test)
cov = np.cov(y_pred, y_test)[0, 1]

# Print the evaluation metrics
print("R² on test set:", r2)
print("MAE on test set:", mae)
print("Mean on test set:", mean)
print("Covariance between predictions and true values on test set:", cov)

# Save the best model
joblib.dump(best_model, 'Model_DT_N.pkl')

# Import new data for prediction
df = pd.read_csv('Data_N_R.csv')

# Features and target variable for the new data
X1 = df.drop('Pt', axis=1)  # Drop the target column
y1 = df['Pt']  # Target variable is 'Pt'

# Predict using the best model
y_pred = best_model.predict(X1)

# Save the predictions as a CSV file
predictions_df = pd.DataFrame({'True': y1, 'Predicted': y_pred})
predictions_df.to_csv('Predictions_N.csv', index=False)

# Calculate the ratio of predicted to actual values
ratios = y_pred / y1

# Calculate the mean, variance, max, and min of the ratios
mean_ratio = np.mean(ratios)
var_ratio = np.var(ratios)
max_ratio = np.max(ratios)
min_ratio = np.min(ratios)

# Calculate R² for the predictions
r2 = r2_score(y1, y_pred)

# Output the results
print(f"Ratios - Mean: {mean_ratio}, Variance: {var_ratio}, Max: {max_ratio}, Min: {min_ratio}")
print(f"R^2: {r2}")
