import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error, explained_variance_score
import joblib

# 加载最佳模型
best_model = joblib.load('Model_DT_N.pkl')

# 导入数据 - 文件1
df1 = pd.read_csv('Data_Train_R.csv')  # 假设文件名为 File1.csv
# 特征和目标变量
X1 = df1.drop('Pt', axis=1)  # 假设 'Pt' 是目标变量
y1 = df1['Pt']

# 预测
y_pred1 = best_model.predict(X1)

# 计算指标
r2_score1 = r2_score(y1, y_pred1)
mae1 = mean_absolute_error(y1, y_pred1)  # 改为计算 MAE
rmse1 = mean_squared_error(y1, y_pred1, squared=False)  # mean_squared_error 默认 squared=True，需要设置为 False 来得到 RMSE
cov1 = explained_variance_score(y1, y_pred1)  # 注意：COV 通常指方差解释率

# 将预测结果保存为CSV文件
predictions_df1 = pd.DataFrame({'True': y1, 'Predicted': y_pred1})
predictions_df1.to_csv('Predictions_File1.csv', index=False)

# 导入数据 - 文件2
df2 = pd.read_csv('Data_Test_R.csv')  # 假设文件名为 File2.csv
# 假设文件2有相同的列，并且 'Pt' 同样是目标变量
X2 = df2.drop('Pt', axis=1)
y2 = df2['Pt']

# 预测
y_pred2 = best_model.predict(X2)

# 计算指标
r2_score2 = r2_score(y2, y_pred2)
mae2 = mean_absolute_error(y2, y_pred2)  # 改为计算 MAE
rmse2 = mean_squared_error(y2, y_pred2, squared=False)
cov2 = explained_variance_score(y2, y_pred2)

# 将预测结果保存为CSV文件
predictions_df2 = pd.DataFrame({'True': y2, 'Predicted': y_pred2})
predictions_df2.to_csv('Predictions_File2.csv', index=False)

# 输出结果
print(f"Data_Train_R:")
print(f"R2: {r2_score1}, MAE: {mae1}, RMSE: {rmse1},COV: {cov1}")  # 修改输出结果，替换MSE为MAE
print(f"Data_Test_R:")
print(f"R2: {r2_score2}, MAE: {mae2}, RMSE: {rmse2}, COV: {cov2}")

# 获取超参数取值
if hasattr(best_model, 'best_params_'):
    # 对于带有 `best_params_` 属性的模型（如使用了网格搜索的模型）
    hyperparameters = best_model.best_params_
elif hasattr(best_model, 'get_params'):
    # 对于一般的模型，可以使用 `get_params` 方法获取超参数
    hyperparameters = best_model.get_params()
else:
    hyperparameters = None

print("Hyperparameters of the model:")
print(hyperparameters)