import pandas as pd
from sklearn.model_selection import KFold, GridSearchCV
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import numpy as np
import joblib

# Read the training dataset
df_train = pd.read_csv('Data_Train_R.csv')

# Read the test dataset
df_test = pd.read_csv('Data_Test_R.csv')

# Features and target variable for the training set
X_train = df_train.drop('Pt', axis=1)  # Drop the target column
y_train = df_train['Pt']  # Target variable is 'Pt'

# Features and target variable for the test set
X_test = df_test.drop('Pt', axis=1)  # Drop the target column
y_test = df_test['Pt']  # Target variable is 'Pt'

# Print the shape of the training and test datasets
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)

# This version provides the grid search algorithm. The hybrid algorithms #
# (including binary search, genetic algorithms, particle swarm optimization, etc.) #
# will be included in future updates
param_grid = {
    'n_neighbors': [2, 3, 4, 5, 6, 7, 9],  # Number of neighbors (K value)
}

# Initialize the K-Nearest Neighbors regressor
knn_reg = KNeighborsRegressor()

# Initialize 10-fold cross-validation
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# List to store the best parameters and scores for each round
best_params_scores = []

# Repeat the training process for 10 rounds
for round_num in range(10):
    print(f"Round {round_num + 1}")

    # Initialize GridSearchCV for hyperparameter tuning
    grid_search = GridSearchCV(estimator=knn_reg, param_grid=param_grid, cv=kf, scoring='r2')

    # Perform grid search on the training set
    grid_search.fit(X_train, y_train)

    # Get the best parameters and model
    best_params = grid_search.best_params_
    best_score = grid_search.best_score_
    best_params_scores.append((best_params, best_score))

# Find the best parameters based on the highest average score
best_params_avg_score = max(best_params_scores, key=lambda x: x[1])[0]
print("Best parameters based on average score across 10 rounds:", best_params_avg_score)

# Train the model again using the best parameters on the entire training set
best_model = KNeighborsRegressor(**best_params_avg_score)
best_model.fit(X_train, y_train)

# Evaluate the model's performance
y_pred = best_model.predict(X_test)

# Calculate R²
r2 = r2_score(y_test, y_pred)

# Calculate MAE (Mean Absolute Error)
mae = mean_absolute_error(y_test, y_pred)

# Calculate RMSE (Root Mean Squared Error)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

# Calculate the mean and covariance between predictions and actual values
mean = np.mean(y_pred / y_test)
cov = np.cov(y_pred, y_test)[0, 1]

# Print the evaluation metrics
print("R² on test set:", r2)
print("MAE on test set:", mae)
print("Mean on test set:", mean)
print("RMSE on test set:", rmse)
print("Covariance between predictions and true values on test set:", cov)

# Save the best model
joblib.dump(best_model, 'Model_KNN_N.pkl')

# Import new data for prediction
df = pd.read_csv('Data_N_R.csv')

# Features and target variable for the new data
X1 = df.drop('Pt', axis=1)  # Drop the target column
y1 = df['Pt']  # Target variable is 'Pt'

# Predict using the best model
y_pred = best_model.predict(X1)

# Save the predictions as a CSV file
predictions_df = pd.DataFrame({'True': y1, 'Predicted': y_pred})
predictions_df.to_csv('Predictions_N.csv', index=False)
